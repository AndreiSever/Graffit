<nav class="nav-backdrop">
    <div class="container navbar">
        <div class="menu text">
            <a href="/about_company.php">
                <div class="text_size-16">
                    О компании
                </div>
            </a>
            <img src="image/Line 1.png"/>
            <a href="/products.php">
                <div class="text_size-16">
                    Продукция
                </div>
            </a>
            <img src="image/Line 1.png"/>
            <a href="/">
                <div class="text_size-16">
                    Производство
                </div>
            </a>
            <img src="image/Line 1.png"/>
            <a href="/buy_grafit.php">
                <div class="text_size-16">
                    Закуп графита
                </div>
            </a>
            <img src="image/Line 1.png"/>
            <a href="/guide.php">
                <div class="text_size-16">
                    Справочник
                </div>
            </a>
            <img src="image/Line 1.png"/>
            <a href="/contacts.php">
                <div class="text_size-16">
                    Контакты
                </div>
            </a>
        </div>
        <form class="d-flex">
            <img class="search" src="image/search.png" /></img>
            <input class="form-control text .text_size-14" type="search" placeholder="Поиск" aria-label="Search">
        </form>
    </div> 
</nav>