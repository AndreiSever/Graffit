        <footer>
            <div class="container navbar">
                <a href="/">
                    <div>
                        <img src="image/logo.png"/>
                    </div>
                </a>
                <div class="menu text">
                    <a href="/">
                        <div class="text_size-16">
                            О компании
                        </div>
                    </a>
                    <a href="/">
                        <div class="text_size-16">
                            Продукция
                        </div>
                    </a>
                    <a href="/">
                        <div class="text_size-16">
                            Производство
                        </div>
                    </a>
                    <a href="/">
                        <div class="text_size-16">
                            Закуп графита
                        </div>
                    </a>
                    <a href="/">
                        <div class="text_size-16">
                            Справочник
                        </div>
                    </a>
                    <a href="/">
                        <div class="text_size-16">
                            Контакты
                        </div>
                    </a>
                </div>
        </footer>
        <div class="copyright">
            © 2007-2021, компания «ГрафитСервис».
        </div>
    </body>
</html>